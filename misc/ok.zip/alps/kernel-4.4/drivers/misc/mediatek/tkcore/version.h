#ifndef TKCORE_VERSION_H
#define TKCORE_VERSION_H

static const char tkcore_nsdrv_version[] = "3.1p9" "\n";

#endif
